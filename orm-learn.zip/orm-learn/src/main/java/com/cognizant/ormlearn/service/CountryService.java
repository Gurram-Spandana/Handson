package com.cognizant.ormlearn.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.JpaSort;
import org.springframework.stereotype.Service;

import com.cognizant.ormlearn.model.Country;
import com.cognizant.ormlearn.repository.CountryRepository;
import com.cognizant.ormlearn.service.exception.CountryNotFoundException;

@Transactional
@Service
public class CountryService {

	@Autowired
	CountryRepository countryRepository;

	public List<Country> getAllCountries() {
		return countryRepository.findAll();
	}

	public Country findCountryByCode(String countryCode) throws CountryNotFoundException {
		Optional<Country> result = countryRepository.findById(countryCode);

		if (!result.isPresent()) {
			throw new CountryNotFoundException("Country is not present");
		}
		Country country = result.get();
		return country;
	}

	public void addCountry(Country country) {
		countryRepository.save(country);
	}

	public void updateCountry(String countryCode, String name) {
		Optional<Country> result = countryRepository.findById(countryCode);
		Country country = result.get();
		country.setName(name);
		countryRepository.save(country);
	}

	public void deleteCountry(String countryCode) {
		countryRepository.deleteById(countryCode);
	}

	public List<Country> searchCountry(String search) {
		return countryRepository.getCountriesBySearch(search, JpaSort.unsafe("name"));
	}
	
	public List<Country> searchCountryStartsWith(char search) {
		return countryRepository.getCountriesByFirstAlphabet(search);
	}

}
