package org.example;

import java.util.List;
import java.util.Scanner;

import org.example.model.Trainee;
import org.example.service.TraineeService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class TraineeManagerApplication {
	private static final Logger LOGGER = LoggerFactory.getLogger(TraineeManagerApplication.class);
	public static void main(String[] args) {
		ApplicationContext ctx=SpringApplication.run(TraineeManagerApplication.class, args);
		TraineeService ss=(TraineeService)ctx.getBean(TraineeService.class);
		Integer port=8080;
        String serverName="MyServer";

		Scanner sc = new Scanner(System.in);

		LOGGER.info("Enter an option:");
		int choice = 0;
		do {
			LOGGER.info("1. Register trainee " + "\n" + "2. Remove trainee " + "\n"
					+ "3. Find by name " + "\n" + "4.Find All"+"\n" + "5.Exit");
			choice = sc.nextInt();
			switch (choice) {
			case 1:
				sc.nextLine();
				LOGGER.info("Enter Trainee name:");
				String name = sc.nextLine();
				LOGGER.info("Enter Email:");
				String email = sc.next();
				
				LOGGER.info("Enter Cohort code:");
				String cohortCode = sc.next();
				
				LOGGER.info("Enter Emp Id:");
				int ID=sc.nextInt();
				String result=ss.createTrainee(new Trainee(ID,name,email,cohortCode));
				LOGGER.info(result);
				break;
			
			case 2:
				LOGGER.info("Enter Trainee id to remove:");
				int id = sc.nextInt();

				String result1=ss.removeTrainee(id);
				LOGGER.info(result1);
				break;
				
			case 3: 
				LOGGER.info("Enter Trainee name to find:");
				String traineeName = sc.next();
				
				List<Trainee> li=ss.searchTraineeByName(traineeName);
				li.stream().forEach(System.out::println);
				
				break;
			
			case 4:
				LOGGER.info("All Trainee Details...");
				List<Trainee> li2=ss.getAllTrainee();
				li2.stream().forEach(System.out::println);
				break;
			default:
				break;
			}
		} while (choice != 5);

		LOGGER.info("Thank You!!!");
		sc.close();
	}
}
