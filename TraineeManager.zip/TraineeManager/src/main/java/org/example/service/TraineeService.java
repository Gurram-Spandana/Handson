package org.example.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.example.exception.InvalidTraineeDataException;
import org.example.model.Trainee;

import org.example.repository.TraineRepo;

@Service
public class TraineeService {
	@Autowired
	private TraineRepo repo;
	public String createTrainee(Trainee t) {
		String validCohort = "^[A-Za-z]{3}[0-9]{2}[A-Za-z]{2}[0-9]{2}";
		Pattern cohortPattern = Pattern.compile(validCohort);
		Matcher cohortMatcher = cohortPattern.matcher(t.getCohortCode());
		if (!cohortMatcher.matches()) {
			throw new InvalidTraineeDataException("Cohort code should be in the following format, AAAXXAAXX, A is for alphabet and X is for number");
		}
		repo.saveAndFlush(t);
		return "Trainee Created!!!!";
		String validEmail = " \"^(.+)@(.+)$\";";
		Pattern emailPattern = Pattern.compile(validEmail);
		Matcher emailMatcher = emailPattern.matcher(t.getEmail());
		if (!emailMatcher.matches()) {
			throw new InvalidTraineeDataException("Make sure email is in correct forma");
		}
		char[] chars = t.getName().toCharArray();
		for (char c : chars) {
			if (Character.isDigit(c))
				throw new InvalidTraineeDataException("The name fields cannot have numeric data");
		}
		if (String.valueOf(t.getEmpid()).length() != 6) {
			throw new InvalidTraineeDataException("Empid has to have 6 numbers");
		}
		
	}
	public String removeTrainee(int empid){
		Optional<Trainee> op=repo.findById(empid);
		if(op.isPresent()) {
			repo.delete(op.get());
			return "Trainee Deleted!!!";
		}	
		else {
			return "Trainee is not under the cohert!!!";
		}
			
	}
	public List<Trainee> searchTraineeByName(String name){
		return repo.findTraineeByName(name);
	}
	public List<Trainee> getAllTrainee(){
		return repo.findAll();
	}
	

}
