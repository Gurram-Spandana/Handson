package com.day57.handson;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day57ApplicationTests {

	@Test
	void contextLoads() {
	}

}
