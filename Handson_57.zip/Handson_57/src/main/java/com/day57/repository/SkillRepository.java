package com.day57.repository;
import org.springframework.data.jpa.repository.JpaRepository;

import com.day57.model.Skill;

public interface SkillRepository extends JpaRepository<Skill, Integer> {

}
